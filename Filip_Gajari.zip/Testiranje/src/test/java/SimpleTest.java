import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import sun.awt.windows.ThemeReader;

import java.util.List;

import java.util.concurrent.TimeUnit;

public class SimpleTest {

    WebDriver driver;

    public void invokeBrowser() {
        try {
            System.setProperty("webdriver.chrome.driver", "C:/Users/Filip/Downloads/chromedriver.exe");
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            driver.manage().deleteAllCookies();
            driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
            driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
            //navigateTest();
            //searchTest();
            //getTest();
            //registrationTest();
            //loginTest();
            //calendarTest();
            //basketTest();
            //scrollTest();
            //hideShowScoresTest();

            //NAPOMENA: ovisno o testu koji se zeli provesti, odkomentira se zeljena metoda. Unutar maina, dolja, poziva se metoda invokeBrowser (main se ne treba nista dirati).
        }
        catch(Exception e){
            e.printStackTrace();
        }
    }

    public void getTest() {
        try {
            driver.get("http://www.nba.com");
            String titleOfPage = driver.getTitle();
            System.out.println(titleOfPage);
            driver.findElement(By.linkText("News")).click();
            String currentUrl = driver.getCurrentUrl();
            System.out.println(currentUrl);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public void navigateTest(){
        try {
            driver.get("http://www.nba.com");
            driver.findElement(By.linkText("Scores")).click();
            Thread.sleep(2000);
            driver.navigate().back();
            Thread.sleep(2000);
            driver.navigate().forward();
            Thread.sleep(2000);
            driver.navigate().refresh();
        }
        catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    public void searchTest(){
        try {
            driver.get("http://www.nba.com");
            driver.findElement(By.className("nba-nav__container--button")).click();
            Thread.sleep(2000);
            driver.findElement(By.className("nba-nav__search")).click();
            Thread.sleep(2000);
            driver.findElement(By.className("nba__search-results--bar")).sendKeys("Lebron James");
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"block-league-content\"]/search/search-results/div[1]/form/input[2]")).click();
            Thread.sleep(3000);
        }
        catch (InterruptedException e){
            e.printStackTrace();
        }
    }

    public void registrationTest() {
        try {
            driver.get("http://www.nba.com");
            driver.findElement(By.className("nba-nav__account")).click();
            Thread.sleep(2000);
            driver.findElement(By.linkText("Account Details")).click();
            Thread.sleep(2000);
            driver.findElement(By.id("nbaMembershipCreateAccountLink")).click();
            Thread.sleep(2000);
            driver.findElement(By.name("emailAddress")).sendKeys("johndoe420420420024@gmail.com");
            Thread.sleep(1000);
            driver.findElement(By.name("password")).sendKeys("Aghdrwu_12342");
            Thread.sleep(1000);
            driver.findElement(By.name("nbaMembershipPersonalizeMonth")).sendKeys("04");
            Thread.sleep(1000);
            driver.findElement(By.name("nbaMembershipPersonalizeDay")).sendKeys("14");
            Thread.sleep(1000);
            driver.findElement(By.name("nbaMembershipPersonalizeYear")).sendKeys("1996");
            Thread.sleep(1000);

            Select country = new Select(driver.findElement(By.name("country")));
            country.selectByVisibleText("Croatia");
            Thread.sleep(2000);

            driver.findElement(By.name("postalcode")).sendKeys("53244");
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"nbaMembenbaMembershipTCPP\"]/label[1]")).click(); //checkbox
            Thread.sleep(2000);
            driver.findElement(By.id("nbaMembershipButtonCreateAccount")).click();
            Thread.sleep(10000);

            //NAPOMENA: ovdje je samo step1 kod registracije zbog toga sto kad se stisne na Agree and Continue, stranica se, iz nekog glupog razloga, loada u beskonačnost i nikad se ne pređe na step2 i step3 (barem je tako kod mene, probao sam sa 3 različita gmail accounta napraviti nba account). Međutim, accounti se naprave iako sam svali put prekinuo loading. Nesto do stranice nije uredu.
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void loginTest() {
        try {
            driver.get("http://www.nba.com");
            driver.findElement(By.className("nba-nav__account")).click();
            Thread.sleep(2000);
            driver.findElement(By.linkText("Account Details")).click();
            Thread.sleep(2000);
            driver.findElement(By.name("emailAddress")).sendKeys("johndoe420420420024@gmail.com");
            Thread.sleep(2000);
            driver.findElement(By.name("password")).sendKeys("Aghdrwu_12342");
            Thread.sleep(2000);
            driver.findElement(By.className("nbaMembershipButtonRight")).click();
            Thread.sleep(10000);

        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public void calendarTest() {
        try {
            driver.get("https://www.nba.com");
            driver.findElement(By.xpath("//*[@id=\"block-scoreboardblock\"]/scoreboard/div/section/div[2]/date-nav/date-bar/div/div[3]/button")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"block-scoreboardblock\"]/scoreboard/div/section/div[2]/date-nav/date-bar/div/div[1]/button")).click();
            Thread.sleep(2000);
            driver.findElement(By.className("calendar_day")).click();
            Thread.sleep(2000);

            ((JavascriptExecutor)driver).executeScript("scroll(0,200)");
            Thread.sleep(2000);

            driver.findElement(By.xpath("//*[@id=\"nbaCalendar\"]/div/table/tbody/tr[5]/td[2]/button")).click(); //NAPOMENA: u ovom slucaju odabire se 28.1.2019.; za svaki drugi datum mora se promjeniti xpath
            Thread.sleep(2000);

            driver.findElement(By.className("calendar_day")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"nbaCalendar\"]/div/div[1]/div[2]/button")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"nbaCalendar\"]/div/div[1]/div[3]/button")).click();
            Thread.sleep(2000);



            /*WebElement findeDate = driver.findElement(By.xpath("//*[@id=\"nbaCalendar\"]/div/table/tbody"));

            List<WebElement> days = findeDate.findElements(By.tagName("td"));

            for(WebElement cell: days){
                cell.getText().equals("31");
                cell.click();
                Thread.sleep(2000);
                break;
            }*/


        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public void basketTest() { //NAMPOMEN: u jednoj metoid sam napravio da se dodaje i mice iz kosarice kako bih smanjio kod
        try {
            /*dodavanje u kosaricu*/
            driver.get("http://www.nba.com");
            driver.findElement(By.xpath("//*[@id=\"block-mainnavigation\"]/nav/div[3]/ul[1]/li[2]/button")).click();
            Thread.sleep(2000);
            driver.findElement(By.linkText("Jerseys")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"browseResultsGrid\"]/div[1]/div[2]/browse-product/a/div[1]/img")).click();
            Thread.sleep(2000);

            ((JavascriptExecutor)driver).executeScript("scroll(0,300)");
            Thread.sleep(2000);

            driver.findElement(By.xpath("//*[@id=\"productDetailsSize\"]/div/ul/li[3]/span")).click();
            Thread.sleep(2000);
            driver.findElement(By.xpath("//*[@id=\"productDetailsQuantity\"]/div/fan-quantity-adjuster/div/ul/li[3]")).click();
            Thread.sleep(2000);

            ((JavascriptExecutor)driver).executeScript("scroll(0,450)");
            Thread.sleep(2000);

            driver.findElement(By.xpath("//*[@id=\"productDetailsActions\"]/button")).click();
            Thread.sleep(2000);

            /*micanje iz kosarice*/
            driver.findElement(By.id("viewBasketBtn")).click();
            Thread.sleep(2000);

            ((JavascriptExecutor)driver).executeScript("scroll(0,150)");
            Thread.sleep(2000);

            driver.findElement(By.xpath("//*[@id=\"basketContent\"]/div/table/tbody[2]/tr/td[3]/a")).click();
            Thread.sleep(2000);
            driver.findElement(By.linkText("OK")).click();
            Thread.sleep(4000);

        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public void scrollTest(){
        try{
            driver.get("http://www.nba.com");
            JavascriptExecutor j = (JavascriptExecutor)driver;

            j.executeScript("scroll(0,1000)");
            Thread.sleep(2000);
            j.executeScript("scroll(0, -1000)");
            Thread.sleep(2000);

        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    public void hideShowScoresTest() {
        try {
            driver.get("http://www.nba.com");
            driver.findElement(By.xpath("//*[@id=\"block-scoreboardblock\"]/scoreboard/div/section/div[1]/ul/li[3]/scoreboard-score-toggle")).click();
            Thread.sleep(5000);
            driver.findElement(By.xpath("//*[@id=\"block-scoreboardblock\"]/scoreboard/div/section/div[1]/ul/li[3]/scoreboard-score-toggle")).click();
            Thread.sleep(4000);
        }
        catch (Exception e){
            e.printStackTrace();
        }
    }

    @AfterMethod
    public void teardownTest() {
        driver.quit();
    }

    public static void main(String[] args) {
        SimpleTest obj = new SimpleTest();
        obj.invokeBrowser();

        obj.teardownTest();
    }
}




